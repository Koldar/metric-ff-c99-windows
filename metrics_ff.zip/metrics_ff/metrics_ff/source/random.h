#ifndef _RANDOM_HEADER__
#define _RANDOM_HEADER__

void srandom(unsigned short seed);

unsigned long random();

#endif

