Introduction
============

This repository contains Metric Fast Forward code, made compliant with modern c99 compilers.
No changes have been made into the planner whatsoever.

I'm not the author of the planner itself. see the planner homepage https://fai.cs.uni-saarland.de/hoffmann/ff.html for further information. Use this porting at your own discretion.

Installation
============

To create the executable in `build` directory, execute in the project root:

```
make
```

To show a brief help of the planner, use:

```
./ff
```